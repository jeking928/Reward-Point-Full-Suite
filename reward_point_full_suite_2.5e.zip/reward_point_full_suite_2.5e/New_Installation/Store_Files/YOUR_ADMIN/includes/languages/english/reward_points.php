<?php
define('HEADING_TITLE', 'Reward Points');
define('HEADING_TITLE_SEARCH', 'Reward Points ID:');
define('HEADING_TITLE_GOTO', 'Jump:');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_CATEGORIES_PRODUCTS', 'Categories / Products');
define('TABLE_HEADING_MODEL', 'Model');

define('TABLE_HEADING_POINT_RATIO','Ratio');
define('TABLE_HEADING_POINT_BONUS','Bonus');

define('TABLE_HEADING_ACTION', 'Action');
define('TABLE_HEADING_STATUS', 'Status');

define('TEXT_CATEGORIES', 'Categories:');
define('TEXT_SUBCATEGORIES', 'Subcategories:');
define('TEXT_PRODUCTS', 'Products:');

define('TEXT_SET_GLOBAL_POINTS_RATIO', 'Enter global points ratio:');
?>