<?php
	$autoLoadConfig[90][] = array('autoType'=>'class',
                              'loadFile'=>'observers/class.reward_points.php');
	$autoLoadConfig[90][] = array('autoType'=>'classInstantiate',
                              'className'=>'RewardPoints',
                              'objectName'=>'RewardPoints');
?>