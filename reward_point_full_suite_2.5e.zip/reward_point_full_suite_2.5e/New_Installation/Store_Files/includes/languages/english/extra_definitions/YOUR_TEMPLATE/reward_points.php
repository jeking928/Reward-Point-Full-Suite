<?php
  define('BOX_REWARD_POINTS', 'Reward Points');
  define('PRODUCT_REWARD_POINT_TAG', 'reward points');
  define('REWARD_POINTS_IN_CART_TAG', 'reward points in cart');
  define('CUSTOMER_EARNED_POINT_TAG', 'points earned');
  define('CUSTOMER_PENDING_POINT_TAG', 'points pending');
  define('MINIMUM_POINT_LEVEL_TAG', 'points minimum');
  define('MAXIMUM_POINT_LEVEL_TAG', 'points maximum');
  define('CUSTOMER_TOTAL_POINT_TAG', 'points total');
  define('NO_REWARD_POINTS_IN_CART_TAG','No points earned yet on current order.');
  define('CUSTOMER_NOT_LOGGED_IN_TAG','Log in to see how many reward points you have already earned');
  define('REWARD_POINT_TITLE','Reward Points');
  define('REWARD_POINT_PROMPT','Total Reward Points: ');
  define('REWARD_POINT_VALUE_PROMPT','Total Reward Point Value: ');
?>